// Copy .env.example to .env and fill in your key
// keys.js reads from EXPO_PUBLIC_GROQ_API_KEY in .env
export const GROQ_API_KEY = process.env.EXPO_PUBLIC_GROQ_API_KEY;
export const GROQ_BASE = 'https://api.groq.com/openai/v1';
